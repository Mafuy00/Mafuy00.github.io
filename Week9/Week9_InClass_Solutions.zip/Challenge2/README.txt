Please find instructions at:
https://docs.google.com/document/d/1M3JdQ8Q4vQ1NsLByOoI-hFy9oDDayFkweQywemHS9nw/edit?usp=sharing
