Please find instructions at:
https://docs.google.com/document/d/1YWtri4Bm8cGHncGE8LgPCo2aM232OIdQIbk_q-_buz8/edit?usp=sharing
