var app = Vue.createApp({
    
    // Data Properties
    data() {
        return {
            
            // DO NOT MODIFY THIS DATA PROPERTY
            weather_types: [
                "Clear",
                "Clouds",
                "Haze",
                "Mist",
                "Rain",
                "Smoke",
                "Snow",
                "Thunderstorm"
            ],

            // DO NOT MODIFY THIS DATA PROPERTY
            weather_type_images: {
                "Clear": "images/clear.jpg",
                "Clouds": "images/clouds.jpg",
                "Haze": "images/haze.jpg",
                "Mist": "images/mist.jpg",
                "Rain": "images/rain.jpg",
                "Smoke": "images/smoke.jpg",
                "Snow": "images/snow.jpg",
                "Thunderstorm": "images/thunderstorm.jpg"
            },

            // DO NOT MODIFY THIS DATA PROPERTY
            temp_images: {
                "Hot": "images/hot.jpg",   // Celsius > 25
                "Okay": "images/okay.jpg", // Celsius 5-25
                "Cold": "images/cold.jpg"  // Celsius < 5
            },

            city: "Singapore", // user input city

            // YOUR OpenWeatherMap API Key
            // Initialize it to your own key
            appid: "",

            weather_photo_paths: [
                "images/question.jpg"
            ],

            temperature_photo_path: "images/question.jpg"

            // ADD MORE DATA PROPERTIES
            // BELOW
            // AS NEEDED
        }
    },

    methods: {

        check_weather() {

            console.log("=== [START] check_weather() ===");

            let api_endpoint_url = `http://api.openweathermap.org/data/2.5/weather?q=${this.city}&appid=${this.appid}&units=metric`;
            console.log(api_endpoint_url)
            
            axios.get(api_endpoint_url)
            .then(response => {
                
                // Inspect the response.data
                // console.log(response.data)
                
                
                // 1) Retrieve weather info such as "Rain"
                //    from response.data
                // YOUR CODE GOES HERE

               

                // 2) Retrieve temperature Celsius such as 30.5
                //    from response.data
                // YOUR CODE GOES HERE


                // Clear the input field
                this.city = '';
                
            })
            .catch(error => {
                console.log(error.message);
            })

            console.log("=== [END] check_weather() ===");
        }
    }

});


// Is the Vue app mounted to the "root" element in weather.html?
// YOUR CODE GOES HERE