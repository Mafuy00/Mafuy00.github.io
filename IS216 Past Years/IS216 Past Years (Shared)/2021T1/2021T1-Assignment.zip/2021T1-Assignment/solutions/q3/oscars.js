// When the webpage loads
function display_default() {

    console.log("[display_default()] Start");
    
    // By default, display all winners (over all decades)
    call_api_get_winners_all();

    console.log("[display_default()] End");

}


function call_api_get_winners_all() {

    console.log("[call_api_get_winners_all()] Start");

    // Step 1
    var request = new XMLHttpRequest();

    // Step 2
    // Register function
    request.onreadystatechange = function() {
        // Step 5
        if( request.readyState == 4 && request.status == 200 ) {
            // Response is ready
            //console.log(request.responseText);
            var json_obj = JSON.parse(request.responseText);
            display_decade_list(json_obj);
            display_winners(json_obj);
        }
    }

    // Step 3
    var final_url = "../api/winner/read.php";
    request.open("GET", final_url, true); // Asynch

    // Step 4
    request.send();

    console.log("[call_api_get_winners_all()] End");
}


function display_decade_list(json_obj) {

    console.log("[display_decade_list()] Start");

    var winner_array = json_obj.records;

    var str = "";

    var digit_array = [];

    // Display winners as cards
    for(var winner of winner_array) {
        
        var movie_year = winner.movie.year;
        var first_three_digits = movie_year.substring(0, 3); // e.g. 1994 --> 199
        digit_array.push(first_three_digits);
    }

    // Remove duplicate years
    var answer = digit_array.reduce(countDuplicates, {});

    var str = "";
    var counter = 0;
    for (const [key, value] of Object.entries(answer)) {
        //console.log(`${key}: ${value}`);

        var new_year_str = key + "0";

        var active = "";
        if( counter == 0 ) {
            active = " active";
        }

        str += `
            <button type="button" class="dropdown-item" onClick="show_winners('${new_year_str}')">
                ${new_year_str}
                <span class="badge badge-warning badge-pill">${value}</span>
            </button>
        `;

        counter++;
    }

    document.getElementById("decade_list").innerHTML = str;

    console.log("[display_decade_list()] End");
    
}

function countDuplicates(obj, num) {
    obj[num] = (++obj[num] || 1);
    return obj;
}


function show_winners(decade) {

    console.log("[show_winners()] Start");
    //alert(decade);

    // Call API
    call_api_get_winners_by_decade(decade);

    console.log("[show_winners()] End");

}


function call_api_get_winners_by_decade(decade) {

    console.log("[call_api_get_winners_by_decade()] Start");

    // Step 1
    var request = new XMLHttpRequest();

    // Step 2
    // Register function
    request.onreadystatechange = function() {
        // Step 5
        if( request.readyState == 4 && request.status == 200 ) {
            // Response is ready
            //console.log(request.responseText);
            var json_obj = JSON.parse(request.responseText);
            display_winners(json_obj);
        }
    }

    // Step 3
    var base_url = "../api/winner/search.php";
    var final_url = base_url + "?d=" + decade;
    request.open("GET", final_url, true); // Asynch

    // Step 4
    request.send();

    console.log("[call_api_get_winners_by_decade()] End");
}


function display_winners(json_obj) {

    console.log("[display_winners()] Start");

    var winner_array = json_obj.records;

    var str = "";

    // Display winners as cards
    for(var winner of winner_array) {
        str += `
        <div class="card">
            <img class="card-img-top" 
                    src="../api/images/${winner.others.image}" 
                    alt="${winner.bio.name}">
            <div class="card-body">
                <h5 class="card-title">${winner.bio.name}</h5>
                <p class="card-text">
                    <span style="font-weight: bold">
                        ${winner.movie.title} (${winner.movie.year})
                    </span>
                    <br>
                    <span style="font-style: italic">
                        ${winner.movie.description}
                    </span>
                </p>
            </div>
        </div>
    `;
    }

    // Add cards to <div id="winner_cards" class="card-columns">
    document.getElementById("winner_cards").innerHTML = str;

    console.log("[display_winners()] End");

}