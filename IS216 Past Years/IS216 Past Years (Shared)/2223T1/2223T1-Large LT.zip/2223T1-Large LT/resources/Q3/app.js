/*
    
Name:   
Email:  

*/


/*  use the following predefined global variables as you deem fit
    you may also define additional variables if necessary
*/
var door1 =  document.getElementById('door1');
var door2 =  document.getElementById('door2');
var light1 = document.getElementById('light1');
var light2 = document.getElementById('light2');
var couch =  document.getElementById('couch');
var isAlarmActive = false 

// add event listener codes below


// implement the event handling functions below
function door1Func() {

    // Add Code Here
   
}

function door2Func() {

    // Add Code Here
   
}

function couchFunc() {

     // Add Code Here
   
}
