/*
    
Name:   
Email:  

*/

function display_character(parentElement, character) {

}


function display_game(tableElement, game) {

}


function check_guess(answer, guess) {
	
}
