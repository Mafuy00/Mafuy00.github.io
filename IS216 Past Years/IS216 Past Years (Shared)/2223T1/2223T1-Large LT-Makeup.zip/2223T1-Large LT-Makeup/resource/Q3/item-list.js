/*
   Name: 
   Email ID:
*/

/*
   Sample rendered DOM structure for the Vue component for your reference:
      <div style="background-color: lightyellow; padding: 10px;">
         <h1 style="color: white; background-color: darkgreen;">Fruits section</h1>
         <label> <input type="checkbox" value="apple"> apple </label>
         <label> <input type="checkbox" value="grape"> grape </label>
         <label> <input type="checkbox" value="orange"> orange </label>
         <label> <input type="checkbox" value="pear"> pear</label>
         <br>
         <button type="button">Choose all</button>
         &nbsp;
         <button type="button">Buy</button>
      </div>
*/

// YOUR CODE GOES HERE
