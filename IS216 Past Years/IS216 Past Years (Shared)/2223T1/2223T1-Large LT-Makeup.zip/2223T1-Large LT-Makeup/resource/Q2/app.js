/*
    
Name:   
Email:  

*/

function display_grid(tableElement, puzzle) {
}


function find_word(word, puzzle) {

}


function color_words(tableElement, foundList, colorList, puzzle) {

}
