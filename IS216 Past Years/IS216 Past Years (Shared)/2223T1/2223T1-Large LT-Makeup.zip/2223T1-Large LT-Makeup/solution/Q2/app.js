 //5 marks
function display_grid(tableElement, puzzle){
    for (row of puzzle){
        let trow = document.createElement("tr");
        tableElement.appendChild(trow);

        for (letter of row){
            let cell = document.createElement("td");
            trow.appendChild(cell);
            cell.innerText = letter
        }
    }
}
//2 marks
function find_word(word, puzzle){
    column_count = puzzle[0].length
    row_count = puzzle.length
    word_len = word.length
    for (row = 0; row < puzzle.length; row++){
        rowToString = puzzle[row].join("")
        if (rowToString.includes(word)){
            col = rowToString.indexOf(word)
            if (col != -1){
                return {"word": word, "row": row, "col": col, "direction": "horizontal"}
            }
        } else {
            startIndex = 0      
            while (rowToString.indexOf(word[0],startIndex) > -1) {
                col = rowToString.indexOf(word[0],startIndex)
                exist = true
                for (i = 0; i < word.length; i++) {
                    read_row = i + row
                    if (word[i] != puzzle[read_row][col]){
                        exist = false
                        break
                    }
                }           
                if (exist){
                    return {"word": word, "row": row, "col": col, "direction": "vertical"}
                }
                startIndex++
           }
        }
    }
}
//3 marks
function color_words(tableElement, foundList, colorList, puzzle){
    display_grid(tableElement, puzzle)
    for(find of foundList){
        wordLen = find.word.length
        if (find.direction == "vertical"){
            for(i = find.row; i < (find.row + wordLen); i++){
                cell = tableElement.getElementsByTagName("tr")[i].getElementsByTagName("td")[find.col]
                cell.style.backgroundColor = colorList[foundList.indexOf(find)]
            }
        } else if (find.direction == "horizontal"){
            for(i = find.col; i < (find.col + wordLen); i++){
                cell = tableElement.getElementsByTagName("tr")[find.row].getElementsByTagName("td")[i]
                cell.style.backgroundColor = colorList[foundList.indexOf(find)]
            }
        }
    } 
}