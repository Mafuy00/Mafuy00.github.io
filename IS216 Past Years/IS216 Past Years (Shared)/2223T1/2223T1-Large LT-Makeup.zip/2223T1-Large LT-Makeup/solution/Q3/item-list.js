/*
   Name: 
   Email ID:
*/

/*
   Sample rendered DOM structure for the Vue component for your reference:
      <div style="background-color: lightyellow; padding: 10px;">
         <h1 style="color: white; background-color: darkgreen;">Fruits section</h1>
         <label> <input type="checkbox" value="apple"> apple </label>
         <label> <input type="checkbox" value="grape"> grape </label>
         <label> <input type="checkbox" value="orange"> orange </label>
         <label> <input type="checkbox" value="pear"> pear</label>
         <br>
         <button type="button">Choose all</button>
         &nbsp;
         <button type="button">Buy</button>
      </div>
*/

// YOUR CODE GOES HERE

app.component('item-list', {
   props: ['list', 'bg_color'],


   emits: ['click'],


   data() {
      return {
         checkedList: []
      }
   }, // data

   methods: {
      doChooseAll() {
         this.checkedList = this.list;
      },

      doClick() {
         this.$emit('click', this.checkedList);
      }
   }, // methods

   template: `
            <div :style="{'background-color':bg_color, padding: '10px'}">
               <slot></slot>
               <label v-for="item in list">
                  <input type="checkbox" :value="item" v-model="checkedList">
                  {{item}}
               </label>
               <br>
               <button type="button" @click="doChooseAll">Choose all</button>
               &nbsp;
               <button type="button" @click="doClick">Buy</button>
            </div>
          `
});