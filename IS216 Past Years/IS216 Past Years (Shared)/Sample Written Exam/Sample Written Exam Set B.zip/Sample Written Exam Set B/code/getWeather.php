<?php
    $weather = "Today's weather is fine!";
    echo $weather;
?>