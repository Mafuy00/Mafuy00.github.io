<?php
    $msg = [ "msg" => ["We are winning!"] ];

    $data = json_encode($msg);
    echo $data;
?>