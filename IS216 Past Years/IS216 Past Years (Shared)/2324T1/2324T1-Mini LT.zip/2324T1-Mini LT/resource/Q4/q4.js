/*
    NAME:
    EMAIL: 
*/
var url1 = "sales1.json"
var url2 = "sales2.json"


function mergeSales(elem, title, url1, url2) {
    var data = []
    // ADD CODE HERE

    display(elem, data, title)
     
}

function sortSales(elem, title, url1, url2) {
    var data = []
    // ADD CODE HERE
    
    display(elem, data, title)
     
}