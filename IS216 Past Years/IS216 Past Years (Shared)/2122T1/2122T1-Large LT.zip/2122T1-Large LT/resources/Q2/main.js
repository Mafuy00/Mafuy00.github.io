/*
    Name:   
    Email:  
*/

const root = Vue.createApp({

    // Data Properties
    data() {
        return {

            // DO NOT MODIFY THIS
            military_statistics: {
                "USA": {
                    "head_of_state": "Joseph Biden",
                    "flag_relative_url": "flags/usa.jpg",
                    "personnel": {
                        "total_population": 334998398,
                        "total_fit_for_service": 122274415,
                        "total_military_personnel": 1832000
                    }
                },
                "South Korea": {
                    "head_of_state": "Moon Jae In",
                    "flag_relative_url": "flags/southkorea.jpg",
                    "personnel": {
                        "total_population": 51715162,
                        "total_fit_for_service": 21203216,
                        "total_military_personnel": 1130000
                    }
                },
                "North Korea": {
                    "head_of_state": "Kim Jong Un",
                    "flag_relative_url": "flags/northkorea.jpg",
                    "personnel": {
                        "total_population": 25831360,
                        "total_fit_for_service": 5217935,
                        "total_military_personnel": 2000000
                    }
                }
            }
            
        }
    }
})

// EDIT THIS VUE COMPONENT
root.component('country-component', {
    props: [ ],
    
    template: `
        <div style="border: 2px solid blue; margin-top: 20px; padding-left: 10px;">
            <h1> Country Name Goes Here </h1>
            <h2> Head of State: Name Goes Here </h2>
            Image Goes Here
            <h2>Percentage of Military Personnel: 1.23%</h2>
        </div>
    `,

    methods: {
        get_percent_military() {

            return 1.23
        }
    }
})

root.mount("#root")