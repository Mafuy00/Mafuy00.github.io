/*
    Name:   
    Email:  
*/


function reset() {
    
    // YOUR CODE GOES HERE

}

function move() {

    // YOUR CODE GOES HERE

}

// YOU MAY ADD MORE FUNCTIONS IF YOU WISH
