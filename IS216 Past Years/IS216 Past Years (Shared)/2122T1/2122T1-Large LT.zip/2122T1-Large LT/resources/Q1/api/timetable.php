<?php
//=================================================================
// DO NOT MODIFY THIS FILE
//=================================================================
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$data = [
    [
        "name"    => 'Jong Un Kim',
        "courses" => [
            ['IS111', 'Intro Programming', 'MON', 'Morning'],
            ['CS102', 'Discrete Mathematics', 'TUE', 'Afternoon'],
            ['EE200', 'Intro to Circuits', 'TUE', 'Evening'],
            ['WRIT100', 'Writing and Reasoning', 'WED', 'Morning'],
            ['LIT380', 'Intro to Korean Literature', 'FRI', 'Morning']
        ]
    ],
    [
        "name"    => 'Donald Trump',
        "courses" => [
            ['IS112', 'Data Management', 'TUE', 'Morning'],
            ['WRIT100', 'Writing and Reasoning', 'WED', 'Morning'],
            ['OBHR101', 'Leadership Team Building', 'WED', 'Afternoon'],
            ['IS113', 'Web Application Development', 'THU', 'Evening'],
            ['STAT202', 'Bayesian Logics', 'FRI', 'Afternoon']
        ]
    ],
    [
        "name"    => 'Hillary Clinton',
        "courses" => [
            ['IS111', 'Intro Programming', 'MON', 'Morning'],
            ['IS112', 'Data Management', 'TUE', 'Morning'],
            ['EE200', 'Intro to Circuits', 'TUE', 'Evening'],
            ['OBHR101', 'Leadership Team Building', 'WED', 'Afternoon'],
            ['STAT202', 'Bayesian Logics', 'FRI', 'Afternoon']
        ]
    ],
    [
        "name"    => 'Shinzo Abe',
        "courses" => [
            ['IS111', 'Intro Programming', 'MON', 'Morning'],
            ['IS112', 'Data Management', 'TUE', 'Morning'],
            ['EE200', 'Intro to Circuits', 'TUE', 'Evening'],
            ['IS113', 'Web Application Development', 'THU', 'Evening'],
            ['STAT202', 'Bayesian Logics', 'FRI', 'Afternoon']
        ]
    ],
    [
        "name"    => 'Emmanuel Macron',
        "courses" => [
            ['EE200', 'Intro to Circuits', 'TUE', 'Evening'],
            ['OBHR101', 'Leadership Team Building', 'WED', 'Afternoon'],
            ['IS113', 'Web Application Development', 'THU', 'Evening'],
            ['LIT380', 'Intro to Korean Literature', 'FRI', 'Morning'],
            ['STAT202', 'Bayesian Logics', 'FRI', 'Afternoon']
        ]
    ]
];


$result_arr = array();
$result_arr["timetable"] = $data;

$date = new DateTime(null, new DateTimeZone('Asia/Singapore'));
$result_arr["info"] = array(
    "author" => "Supreme University",
    "response_datetime_singapore" => $date->format('Y-m-d H:i:sP')
);

// set response code - 200 OK
http_response_code(200);

// show response
echo json_encode($result_arr);

?>