/*
    Name:   
    Email:  
*/

const root = Vue.createApp({

    // Data Properties
    data() {
        return {
            
            // DO NOT MODIFY THIS
            greeting: "Welcome to Timetable Summary",

            // DO NOT MODIFY THIS
            instruction: `
                <p style="background-color: yellow; font-size: 22px; font-style: italic;">
                    Press 'Show Timetable Summary' button below, and you will see the summary!
                </p>
            `,

            // DO NOT MODIFY THIS MANUALLY
            // YOU MAY UPDATE THIS DATA PROPERTY'S VALUE USING JAVASCRIPT CODE
            timetable: null,

            //==================================
            // YOU MAY ADD MORE DATA PROPERTIES
            //==================================
        }
    },


    // This runs only ONCE when timetable.html loads for the first time
    created() {
            console.log("===[START] created() ===")

            // Call API and get data
            let api_endpoint_url = "api/timetable.php"

            // Use Axios to call API asynchronously
            axios.get(api_endpoint_url)
            .then(response => {

                // Inspect the response
                console.log(response.data)

                // Save to timetable data property
                this.timetable = response.data.timetable


                //==================
                //      Part C
                //==================
                // response.data.timetable contains all the info you need
                // What can you do here to retrieve the names
                //     and then make it available to <select> ... </select> in timetable.html?
                //
                // Next,
                // Ensure that the first name found in response.data.timetable
                //    is to be pre - selected in <select> ... </select>
                // In the API given to you for testing purposes,
                //    "Jong Un Kim" is the first name to be retrieved from the API response.
                //    Hence, when timetable.html loads for the first time,
                //       "Jong Un Kim" must be pre-selected.
                // Do NOT hardcode "Jong Un Kim" - graders will use different data returned from API !!!
                
                
            })
            .catch(error => {
                console.log(error.message)
            })

            console.log("===[END] created() ===")
    },

    // Methods
    methods: {
        
        show_timetable_summary() {

            console.log("===[START] show_timetable_summary() ===")

            //==================
            //      Part E
            //==================
            // HINT
            // See if you can use this.timetable (data property) which contains students' timetables

            // YOUR CODE GOES HERE
            
            console.log("===[END] show_timetable_summary() ===")
        }

    }

})

root.mount("#root")