/*
    Name:   LEE Oppa
    Email:  lee.oppa.2020
*/

const root = Vue.createApp({

    // Data Properties
    data() {
        return {
            
            greeting: "Welcome to Timetable Summary",

            instruction: `
                <p style="background-color: yellow; font-size: 22px; font-style: italic;">
                    Press 'Show Timetable Summary' button below, and you will see the summary!
                </p>
            `,

            timetable: null,

            show_timetable_summary_flag: false,

            names: [],

            selected_name: "",

            timetable_summary: ""

        }
    },

    // This runs only ONCE when timetable.html loads for the first time
    created() {
            console.log("===[START] created() ===")

            // Call API and get data
            let api_endpoint_url = "api/timetable.php"

            // Use Axios to call API asynchronously
            axios.get(api_endpoint_url)
            .then(response => {

                // 1) Inspect the response
                console.log(response.data)

                // 2) Save timetable data property (array of Objects)
                this.timetable = response.data.timetable 

                // 3) Save names to names data property (array of Strings)
                this.get_names(this.timetable)

                // 4) The first name is to be pre-selected in dropdown
                this.selected_name = this.names[0]
                
            })
            .catch(error => {
                console.log(error.message)
            })

            console.log("===[END] created() ===")
    },

    // Methods
    methods: {

        get_names(timetable) {
            console.log("===[START] get_names() ===")
            
            console.log(timetable)

            for (student_object of timetable) {
                console.log(student_object.name) // name
                
                let name = student_object.name
                this.names.push(name)
            }

            console.log(this.names)
            console.log("===[END] get_names() ===")
        },
        
        show_timetable_summary() {

            console.log("===[START] show_timetable_summary() ===")

            console.log(this.timetable)

            let days = [ "MON", "TUE", "WED", "THU", "FRI"]
            let timeslots = ["Morning", "Afternoon", "Evening"]
            
            let mon = 0
            let tue = 0
            let wed = 0
            let thu = 0
            let fri = 0
            let morning = 0
            let afternoon = 0
            let evening = 0

            for (student_object of this.timetable) {
                console.log(student_object)
                let name = student_object.name
                
                if (name == this.selected_name) {
                    console.log("****** Found student: " + name)

                    let courses = student_object.courses
                    console.log(courses)

                    // Go through courses
                    for (course of courses) {
                        console.log(course)

                        if (course[2] == "MON")
                            mon++
                        else if (course[2] == "TUE")
                            tue++
                        else if (course[2] == "WED")
                            wed++
                        else if (course[2] == "THU")
                            thu++
                        else if (course[2] == "FRI")
                            fri++
                        
                        if (course[3] == "Morning")
                            morning++
                        else if (course[3] == "Afternoon")
                            afternoon++
                        else if (course[3] == "Evening")
                            evening++
                    }

                    break
                }
            }

            let str = `
                <table border='1'>
                    <tr>
                        <th>MON</th>
                        <th>TUE</th>
                        <th>WED</th>
                        <th>THU</th>
                        <th>FRI</th>
                        <th>Morning</th>
                        <th>Afternoon</th>
                        <th>Evening</th>
                    </tr>
                    <tr>
                        <td>${mon}</td>
                        <td>${tue}</td>
                        <td>${wed}</td>
                        <td>${thu}</td>
                        <td>${fri}</td>
                        <td>${morning}</td>
                        <td>${afternoon}</td>
                        <td>${evening}</td>
                    </tr>
            `

            this.timetable_summary = str

            // Make div visible
            this.show_timetable_summary_flag = true
            
            console.log("===[END] show_timetable_summary() ===")
        }

    }

})

root.mount("#root")