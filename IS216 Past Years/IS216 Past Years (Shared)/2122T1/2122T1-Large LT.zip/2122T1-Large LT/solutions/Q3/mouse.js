/*
    Name:   LEE Oppa
    Email:  lee.oppa.2020
*/

const min = 0;
const max = 4;

function reset() {
    document.getElementById('maze').innerHTML = ""
    document.getElementById('button_reset').disabled = true
     document.getElementById('button_move').disabled = false
}

function move() {

    if (document.getElementById('button_reset').disabled) {
        document.getElementById('button_reset').disabled = false
    }

    let mouse_new_row = getRandomInt()
    let mouse_new_col = getRandomInt()
    let cheese_new_row = getRandomInt()
    let cheese_new_col = getRandomInt()

    let str = `
        <table border='1'>
    `

    for (let row = 0; row <= max; row++) {
        str += `
            <tr>
        `

        for (let col = 0; col <= max; col++) {

            let img_src = "images/empty.png"
            if (mouse_new_row == cheese_new_row && mouse_new_col == cheese_new_col) {
                img_src = "images/yummy.png"
                document.getElementById('button_move').disabled = true
            }
            else if (row == mouse_new_row && col == mouse_new_col) {
                img_src = "images/mouse.png"
            }
            else if (row == cheese_new_row && col == cheese_new_col) {
                img_src = "images/cheese.png"
            }

            str += `
                <td>
                    <img src="${img_src}">
                </td>
            `
        }

        str += `
            </tr>
        `
    }

    str += `
        </table>
    `

    document.getElementById('maze').innerHTML = str
}


function getRandomInt() {
    return Math.floor(Math.random() * (max - min + 1) ) + min
}