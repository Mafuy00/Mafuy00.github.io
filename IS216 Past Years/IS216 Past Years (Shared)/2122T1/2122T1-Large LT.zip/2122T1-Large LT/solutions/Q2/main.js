/*
    Name:   LEE Oppa
    Email:  lee.oppa.2020
*/

const root = Vue.createApp({

    // Data Properties
    data() {
        return {

            // DO NOT MODIFY THIS
            military_statistics: {
                "USA": {
                    "head_of_state": "Joseph Biden",
                    "flag_relative_url": "flags/usa.jpg",
                    "personnel": {
                        "total_population": 334998398,
                        "total_fit_for_service": 122274415,
                        "total_military_personnel": 1832000
                    }
                },
                "South Korea": {
                    "head_of_state": "Moon Jae In",
                    "flag_relative_url": "flags/southkorea.jpg",
                    "personnel": {
                        "total_population": 51715162,
                        "total_fit_for_service": 21203216,
                        "total_military_personnel": 1130000
                    }
                },
                "North Korea": {
                    "head_of_state": "Kim Jong Un",
                    "flag_relative_url": "flags/northkorea.jpg",
                    "personnel": {
                        "total_population": 25831360,
                        "total_fit_for_service": 5217935,
                        "total_military_personnel": 2000000
                    }
                }
            }
            
        }
    }
})

root.component('country-component', {
    props: ['country', 'details'],
    
    template: `
        <div style="border: 2px solid blue; margin-top: 20px; padding-left: 10px;">
            <h1>{{ country }} </h1>
            <h2>Head of State: {{ details.head_of_state }} </h2>
            <img v-bind:src="details.flag_relative_url">
            <h2>Percentage of Military Personnel: {{ this.get_percent_military() }}%</h2>
        </div>
    `,

    methods: {
        get_percent_military() {
            let percent_military = Number(this.details.personnel.total_military_personnel) / Number(this.details.personnel.total_population) * 100
            console.log(percent_military)
            return parseFloat(percent_military).toFixed(2)
        }
    }
})

root.mount("#root")