<?php
//=================================================================
// DO NOT MODIFY THIS FILE
//=================================================================
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$data = [
    [
        "Michael Scott",
        
        [
            "quarterly" => [
                [ '2019', 'Q1', 100000 ],
                [ '2019', 'Q2', 150000 ],
                [ '2019', 'Q3', 200000 ],
                [ '2019', 'Q4', '90000' ],
                [ '2020', 'Q1', 10000 ],
                [ '2020', 'Q2', 20000 ],
                [ '2020', 'Q3', 80000 ],
                [ '2020', 'Q4', '30000' ],
                [ '2021', 'Q1', 60000 ],
                [ '2021', 'Q2', 90000 ],
                [ '2021', 'Q3', 30000 ],
                [ '2021', 'Q4', 20000 ]
            ]
        ]
    ],
    [
        "Dwight Schrute",
        
        [
            "quarterly" => [
                [ '2019', 'Q1', '20000' ],
                [ '2019', 'Q2', 10000 ],
                [ '2019', 'Q3', 30000 ],
                [ '2019', 'Q4', 25000 ],
                [ '2020', 'Q1', 50000 ],
                [ '2020', 'Q2', 100000 ],
                [ '2020', 'Q3', '60000' ],
                [ '2020', 'Q4', 90000 ],
                [ '2021', 'Q1', 100000 ],
                [ '2021', 'Q2', 50000 ],
                [ '2021', 'Q3', 60000 ],
                [ '2021', 'Q4', 70000 ]
            ]
        ]
    ],
    [
        "Jim Halpert",
        
        [
            "quarterly" => [
                [ '2019', 'Q1', 5000 ],
                [ '2019', 'Q2', 7000 ],
                [ '2019', 'Q3', 8000 ],
                [ '2019', 'Q4', '9000' ],
                [ '2020', 'Q1', '70000' ],
                [ '2020', 'Q2', 60000 ],
                [ '2020', 'Q3', 30000 ],
                [ '2020', 'Q4', 70000 ],
                [ '2021', 'Q1', '20000' ],
                [ '2021', 'Q2', 50000 ],
                [ '2021', 'Q3', 160000 ],
                [ '2021', 'Q4', 200000 ]
            ]
        ]
    ]
];


$result_arr = array();
$result_arr["sales"] = $data;

$date = new DateTime(null, new DateTimeZone('Asia/Singapore'));
$result_arr["info"] = array(
    "author" => "Supreme Paper Company",
    "response_datetime_singapore" => $date->format('Y-m-d H:i:sP')
);

// set response code - 200 OK
http_response_code(200);

// show response
echo json_encode($result_arr);

?>