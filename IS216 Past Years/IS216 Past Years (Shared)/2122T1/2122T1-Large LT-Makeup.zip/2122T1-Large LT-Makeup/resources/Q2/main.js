/*
    Name:   
    Email:  
*/

const root = Vue.createApp({

    // Data Properties
    data() {
        return {

            // DO NOT MODIFY THIS
            covid_statistics: [
                {
                    "USA": {
                        "population": "334506463",
                        "details": {
                            "url": "https://www.worldometers.info/coronavirus/country/us/"
                        },
                        "covid": {
                            "total_cases": "82649779",
                            "total_deaths": "1018316",
                            "total_recovered": "80434925"
                        }
                    }
                },
                {
                    "Brazil": {
                        "population": "215286941",
                        "details": {
                            "url": "https://www.worldometers.info/coronavirus/country/brazil/"
                        },
                        "covid": {
                            "total_cases": "30345654",
                            "total_deaths": "662663",
                            "total_recovered": "29364400"
                        }
                    }
                },
                {
                    "Germany": {
                        "population": "84267549",
                        "details": {
                            "url": "https://www.worldometers.info/coronavirus/country/germany/"
                        },
                        "covid": {
                            "total_cases": "24138859",
                            "total_deaths": "134646",
                            "total_recovered": "21243000"
                        }
                    }
                }
            ]

        }
    }
})

// EDIT THIS VUE COMPONENT
root.component('covid-component', {
    props: [ ],
    
    template: `
        <div style="border: 2px solid blue; margin-top: 20px; padding-left: 10px;">
            <h1> Country Name Goes Here </h1>
            <h2> Population Goes Here </h2>
            Link Goes Here
            <h2>Mortality Rate (%):  1.234%</h2>
        </div>
    `,

    methods: {
        get_mortality_rate() {
            
            return 1.234

        }
    }
})

root.mount("#root")