/*
    Name:   
    Email:  
*/


function run_dwight() {
    
    // YOUR CODE GOES HERE

}

function run_andy() {

    // YOUR CODE GOES HERE

}

// YOU MAY ADD MORE FUNCTIONS IF YOU WISH