/*
    Name:   LEE Oppa
    Email:  lee.oppa.2020
*/

const min = 0;
const max = 3;

let distance_dwight = 0;
let distance_andy = 0;

function run_dwight() {
    
    if (document.getElementById('track').style.display == 'none') {
        document.getElementById('track').style.display = 'table'
    }

    // Get random distance to travel
    let random_distance = getRandomInt()

    distance_dwight += random_distance // new total distance

    let str = `
        <h1>Dwight just ran ${random_distance}</h1>
        <table border="1">
    `

    let max_distance = distance_dwight
    if (distance_andy > max_distance) {
        max_distance = distance_andy
    }

    for (var i = 1; i <= max_distance; i++) {

        let dwight_cell_image_url = "images/grey.png"
        if (i == distance_dwight) {
            dwight_cell_image_url = "images/dwight.png"
        }
        else if (i > distance_dwight) {
            dwight_cell_image_url = "images/white.png"
        }

        let andy_cell_image_url = "images/grey.png"
        if (i == distance_andy) {
            andy_cell_image_url = "images/andy.png"
        }
        else if (i > distance_andy) {
            andy_cell_image_url = "images/white.png"
        }

        str += `
            <tr>
                <td>
                    <img src="${dwight_cell_image_url}">
                </td>
                <td>
                    <img src="${andy_cell_image_url}">
                </td>
            </tr>
        `
    }

    str += `
        </table>
    `

    document.getElementById('track').innerHTML = str

    document.getElementById('button_dwight').disabled = true
    document.getElementById('button_andy').disabled = false
}

function run_andy() {

    if (document.getElementById('track').style.display == 'none') {
        document.getElementById('track').style.display = 'table'
    }

    // Get random distance to travel
    let random_distance = getRandomInt()

    distance_andy += random_distance // new total distance

    let str = `
        <h1>Andy just ran ${random_distance}</h1>
        <table border="1">
    `

    let max_distance = distance_dwight
    if (distance_andy > max_distance) {
        max_distance = distance_andy
    }

    for (var i = 1; i <= max_distance; i++) {

        let dwight_cell_image_url = "images/grey.png"
        if (i == distance_dwight) {
            dwight_cell_image_url = "images/dwight.png"
        }
        else if (i > distance_dwight) {
            dwight_cell_image_url = "images/white.png"
        }

        let andy_cell_image_url = "images/grey.png"
        if (i == distance_andy) {
            andy_cell_image_url = "images/andy.png"
        }
        else if (i > distance_andy) {
            andy_cell_image_url = "images/white.png"
        }

        str += `
            <tr>
                <td>
                    <img src="${dwight_cell_image_url}">
                </td>
                <td>
                    <img src="${andy_cell_image_url}">
                </td>
            </tr>
        `
    }

    str += `
        </table>
    `

    document.getElementById('track').innerHTML = str

    document.getElementById('button_dwight').disabled = false
    document.getElementById('button_andy').disabled = true
}


function getRandomInt() {
    return Math.floor(Math.random() * (max - min + 1) ) + min
}