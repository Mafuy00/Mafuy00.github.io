/*
    Name:   LEE Oppa
    Email:  lee.oppa.2020
*/

const root = Vue.createApp({

    // Data Properties
    data() {
        return {

            // DO NOT MODIFY THIS
            covid_statistics: [
                {
                    "USA": {
                        "population": "334506463",
                        "details": {
                            "url": "https://www.worldometers.info/coronavirus/country/us/"
                        },
                        "covid": {
                            "total_cases": "82649779",
                            "total_deaths": "1018316",
                            "total_recovered": "80434925"
                        }
                    }
                },
                {
                    "Brazil": {
                        "population": "215286941",
                        "details": {
                            "url": "https://www.worldometers.info/coronavirus/country/brazil/"
                        },
                        "covid": {
                            "total_cases": "30345654",
                            "total_deaths": "662663",
                            "total_recovered": "29364400"
                        }
                    }
                },
                {
                    "Germany": {
                        "population": "84267549",
                        "details": {
                            "url": "https://www.worldometers.info/coronavirus/country/germany/"
                        },
                        "covid": {
                            "total_cases": "24138859",
                            "total_deaths": "134646",
                            "total_recovered": "21243000"
                        }
                    }
                }
            ]

        }
    }
})

root.component('covid-component', {
    props: ['country', 'info'],
    
    template: `
        <div style="border: 2px solid blue; margin-top: 20px; padding-left: 10px;">
            <h1>{{ country }} </h1>
            <h2>Population: {{ info.population }} </h2>
            <a v-bind:href="info.details.url">Link</a>
            <h2>Mortality Rate (%): {{ this.get_mortality_rate() }}%</h2>
        </div>
    `,

    methods: {
        get_mortality_rate() {
            let percent_mortality = Number(this.info.covid.total_deaths) / Number(this.info.covid.total_cases) * 100
            console.log(percent_mortality)
            return parseFloat(percent_mortality).toFixed(3)
        }
    }
})

root.mount("#root")