<?php
//=================================================================
// DO NOT MODIFY THIS FILE
//=================================================================
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$data = [
    "USA" => [
        "population" => "334506463",
        [
            "url" => "https://www.worldometers.info/coronavirus/country/us/"
        ],
        "covid" => [
            "total_cases" => "82649779",
            "total_deaths" => "1018316",
            "total_recovered" => "80434925"
        ]   
    ],
    "Brazil" => [
        "population" => "215286941",
        [
            "url" => "https://www.worldometers.info/coronavirus/country/brazil/"
        ],
        "covid" => [
            "total_cases" => "30345654",
            "total_deaths" => "662663",
            "total_recovered" => "29364400"
        ]   
    ],
    "Germany" => [
        "population" => "84267549",
        [
            "url" => "https://www.worldometers.info/coronavirus/country/germany/"
        ],
        "covid" => [
            "total_cases" => "24138859",
            "total_deaths" => "134646",
            "total_recovered" => "21243000"
        ]   
    ]
];

$result_arr = array();
$result_arr["covid_statistics"] = $data;

$date = new DateTime(null, new DateTimeZone('Asia/Singapore'));
$result_arr["info"] = array(
    "author" => "Global COVID-19 Statistics",
    "response_datetime_singapore" => $date->format('Y-m-d H:i:sP')
);

// set response code - 200 OK
http_response_code(200);

// show response
echo json_encode($result_arr);

?>