/*
    Name:   LEE Oppa
    Email:  lee.oppa.2020
*/

const root = Vue.createApp({

    // Data Properties
    data() {
        return {
            
            greeting: "Welcome to Supreme Paper Company",

            information: `
                <p style="background-color: yellow; font-size: 22px; font-style: italic;">
                    Press 'Show Sales Summary' button below, and you will see the summary!
                </p>
            `,

            sales: null,

            show_sales_summary_flag: false,

            employee_names: [],

            user_selected_name: "",

            sales_summary: ""

        }
    },

    // This runs only ONCE when timetable.html loads for the first time
    created() {
            console.log("===[START] created() ===")

            // Call API and get data
            let api_endpoint_url = "api/sales.php"

            // Use Axios to call API asynchronously
            axios.get(api_endpoint_url)
            .then(response => {

                // 1) Inspect the response
                console.log(response.data)

                // 2) Save data property
                this.sales = response.data.sales 

                // 3) Save names to names data property (array of Strings)
                this.get_names(this.sales)

                // 4) The first name is to be pre-selected in dropdown
                this.user_selected_name = this.employee_names[0]
                
            })
            .catch(error => {
                console.log(error.message)
            })

            console.log("===[END] created() ===")
    },

    // Methods
    methods: {

        get_names(sales) {
            console.log("===[START] get_names() ===")
            
            console.log(sales)

            for (entry of sales) {
                console.log(entry[0]) // name
                
                let name = entry[0]
                this.employee_names.push(name)
            }

            console.log(this.employee_names)
            console.log("===[END] get_names() ===")
        },
        
        show_sales_summary() {

            console.log("===[START] show_sales_summary() ===")

            console.log(this.sales)

            let years = [ "2019", "2020", "2021" ]
            
            let year2019 = 0
            let year2020 = 0
            let year2021 = 0

            for (entry of this.sales) {
                if (entry[0] === this.user_selected_name) {
                    // console.log(entry)

                    let quarterly_array = entry[1].quarterly
                    // console.log(quarterly_array)

                    for (year_quarter_data of quarterly_array) {
                        console.log(year_quarter_data)

                        if(year_quarter_data[0] == "2019") {
                            year2019 += parseInt(year_quarter_data[2])
                        }
                        else if(year_quarter_data[0] == "2020") {
                            year2020 += parseInt(year_quarter_data[2])
                        }
                        else if(year_quarter_data[0] == "2021") {
                            year2021 += parseInt(year_quarter_data[2])
                        }
                    }

                }
            }

            console.log(year2019)
            console.log(year2020)
            console.log(year2021)

            let best_year = "2019"
            let best_year_total = year2019
            if(year2020 > year2019) {
                best_year = "2020"
                best_year_total = year2020
            }
            if (year2021 > best_year_total) {
                best_year = "2021"
                best_year_total = year2021
            }

            let str = `
                <table border='1'>
                    <tr>
                        <th>2019</th>
                        <th>2020</th>
                        <th>2021</th>
                        <th>Best Year</th>
                    </tr>
                    <tr>
                        <td>${year2019}</td>
                        <td>${year2020}</td>
                        <td>${year2021}</td>
                        <td>${best_year}</td>
                    </tr>
            `

            this.sales_summary = str

            // Make div visible
            this.show_sales_summary_flag = true
            
            console.log("===[END] show_sales_summary() ===")
        }

    }

})

root.mount("#root")