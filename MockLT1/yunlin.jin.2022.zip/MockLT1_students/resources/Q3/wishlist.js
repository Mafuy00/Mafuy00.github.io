/*
 Name: Jin Yun Lin
 Email: yunlin.jin.2022
*/

/* YOU MAY MODIFY THIS FILE */


document.getElementById('addButton').addEventListener('click', function() {
    
    // YOUR CODE GOES HERE
    var item = document.getElementById("productInput").value;
    var ul = document.getElementById("wishlist");
    console.log(item);

    var li = document.createElement("li");
    var purchaseBtn = document.createElement("button");
    var removeBtn = document.createElement("button");
    var p = document.createElement("p");
    li.innerText = `${item}`;
    


    purchaseBtn.style.backgroundColor = "green";
    purchaseBtn.style.color= "white";
    purchaseBtn.style.border= "none";
    purchaseBtn.style.padding= "5px 10px";
    purchaseBtn.style.cursor= "pointer";
    purchaseBtn.style.margin = "0px";
    purchaseBtn.style.alignItems = "right"
    purchaseBtn.innerText = `Mark as Purchased`;
    li.appendChild(purchaseBtn);
    
    removeBtn.style.backgroundColor = "red";
    removeBtn.style.color= "white";
    removeBtn.style.border= "none";
    removeBtn.style.padding= "5px 10px";
    removeBtn.style.cursor= "pointer";
    removeBtn.innerText = `Remove`;
    li.appendChild(removeBtn);

    ul.appendChild(li);
    // and then append child
    purchaseBtn.addEventListener('click', function() {
        li.style.textDecoration = "line-through";

        console.log(item);
    });

    removeBtn.addEventListener('click', function() {
        ul.lastElementChild.remove();
        console.log(li);
        // li.lastElementChild.remove();
        var li = document.createElement("li");
    });

    // ADVICE
    // Do not CODE right away
    // Always think through the solution logic as a series of steps
    // Write down the steps as pseudocode as COMMENTS first

});


// Feel free to write more functions here
//   and call these functions from inside the Event Listener function.