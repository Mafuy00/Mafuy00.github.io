/*
    Name:  YOUR NAME GOES HERE (KIM Pyong Yang)
    Email: YOUR SMU EMAIL ID GOES HERE (e.g. kim.pyongyang.2023)
*/

/* YOU MAY MODIFY THIS FILE */


document.getElementById('getPackageBtn').addEventListener('click', function() {

    // YOUR CODE GOES HERE

    // ADVICE
    // Do not CODE right away
    // Always think through the solution logic as a series of steps
    // Write down the steps as pseudocode as COMMENTS first
    
});


document.getElementById('packageSelect').addEventListener('change', function() {

    // YOUR CODE GOES HERE
    
    // ADVICE
    // Do not CODE right away
    // Always think through the solution logic as a series of steps
    // Write down the steps as pseudocode as COMMENTS first
    
});